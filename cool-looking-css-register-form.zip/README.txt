A Pen created at CodePen.io. You can find this one at https://codepen.io/iiSeptum/pen/wHFlc.

 Would look really pretty on a website. I just don't know how to add it to the fricking website :/